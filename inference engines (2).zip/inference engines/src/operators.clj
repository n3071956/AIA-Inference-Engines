(ns operators)

;;----------------ops-search operators
;;----------------
;;World Define
;;----------------
(def world
  '#{(connects j7 c1)
     (connects j7 c2)
     (connects c1 j7)
     (connects c1 j2)
     (connects c2 j7)
     (connects c2 j1)
     (connects j1 c2)
     (connects j1 c4)
     (connects c4 j1)
     (connects c4 j3)
     (connects j2 c1)
     (connects j2 c3)
     (connects c3 j3)
     (connects c3 j2)
     (connects j3 c3)
     (connects j3 c4)
     (connects j3 c5)
     (connects j3 c6)
     (connects c5 j3)
     (connects c5 j4)
     (connects j4 c5)
     (connects j4 c7)
     (connects c7 j4)
     (connects c7 j6)
     (connects j6 c7)
     (connects j6 c8)
     (connects c8 j6)
     (connects c8 j5)
     (connects j5 c8)
     (connects j5 c6)
     (connects c6 j5)
     (connects c6 j3)

     (connects j6 c)
     (connects c j6)
     (top c j6)
     (bottom j6 c)

     (right j7 c1)
     (bottom j7 c2)
     (left c1 j7)
     (right c1 j2)
     (top c2 j7)
     (bottom c2 j1)
     (top j1 c2)
     (right j1 c4)
     (left c4 j1)
     (right c4 j3)
     (left j2 c1)
     (bottom j2 c3)
     (bottom c3 j3)
     (top c3 j2)
     (top j3 c3)
     (left j3 c4)
     (right j3 c5)
     (bottom j3 c6)
     (left c5 j3)
     (right c5 j4)
     (left j4 c5)
     (bottom j4 c7)
     (top c7 j4)
     (bottom c7 j6)
     (top j6 c7)
     (left j6 c8)
     (right c8 j6)
     (left c8 j5)
     (right j5 c8)
     (top j5 c6)
     (bottom c6 j5)
     (top c6 j3)

     (is j7 exit)
     (is c locked)

     (at guard1 j1)
     (facing guard1 c4)
     (has guard1 key)

     (at guard2 j4)
     (facing guard2 c5)

     (at prisoner c)
     (escaped prisoner false)
     })
;;----------------
;;Guard
;;----------------
(def operations-guard
  '{face {:pre (()
                 ()
                 )
          :add (())
          :del (()
                 ())
          :txt ()
          :cmd []
          }
    })

;;----------------
;;Prisoner
;;----------------
(def operations-prisoner
  '{unlock           {:pre ((in prisoner c)
                             (is c locked)
                             )
                      :add ((is c unlocked))
                      :del ((is c locked))
                      :txt (unlocked cell)
                      :cmd []
                      }
    leave-cell       {:pre ((in prisoner c)
                             (is c unlocked)
                             )
                      :add ((on prisoner ?junction))
                      :del ((in prisoner c))
                      :txt (leave cell)
                      :cmd []
                      }
    move-to-junction {:pre ((in prisoner ?corridor)
                             (connects ?corridor ?junction)
                             (moving prisoner ?corridor)
                             )
                      :add ((at prisoner ?junction))
                      :del ((moving prisoner ?corridor))
                      :txt (prisoner moved from ?corridor to ?junction)
                      :cmd []
                      }
    move-to-corridoor {:pre ((in prisoner ?junction)
                              (connects ?junction ?corridor)
                              (at prisoner ?junction)
                             )
                      :add ((moving prisoner ?corridor))
                      :del ((at prisoner ?junction))
                      :txt (prisoner moved from ?junction to ?corridor)
                      :cmd []
                      }
    get-key          {:pre ((on prisoner ?junction)
                             (at ?guard ?junction)
                             (has ?guard key)
                             )
                      :add ((has prisoner key))
                      :del ((has ?guard key))
                      :txt (key twoked)
                      :cmd []
                      }
    exit             {:pre ((has prisoner key)
                             (on prisoner ?junction)
                             (is ?junction exit)
                             (escaped prisoner false)
                             )
                      :add ((escaped prisoner true))
                      :del ((escaped prisoner false))
                      :txt (get rekt m8)
                      :cmd []
                      }
    })
;;----------------
;;Rules
;;----------------

;;----------------Planner operaotrs
;;----------------
;;Guard
;;----------------
;;--face

;;----------------
;;Prisoner
;;----------------
;;--unlock
;;--leave-cell
;;--move
;;--hide
;;--got-key
;;--exit